<?php

$servername = "localhost";
$username = "id21849132_elgranadmin";
$password = "ElGranAdmin000.";
$dbname = "id21849132_lagranbd";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Mostrar datos existentes
$sql_select = "SELECT * FROM persona";
$result = $conn->query($sql_select);

if ($result->num_rows > 0) {
    echo "<h2>Datos existentes en la base de datos:</h2>";
    echo "<table border='1'>";
    echo "<tr><th>Email</th><th>Nombre</th><th>Teléfono</th><th>DNI</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["email"]."</td><td>".$row["nombre"]."</td><td>".$row["telefono"]."</td><td>".$row["dni"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "No hay datos en la base de datos.";
}

$conn->close();

?>
