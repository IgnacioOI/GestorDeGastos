<?php

// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "id21849132_elgranadmin";
$password = "ElGranAdmin000.";
$dbname = "id21849132_lagranbd";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para seleccionar los datos
$sql = "SELECT * FROM persona";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Inicializar un array para almacenar los resultados
    $response = array();

    // Recorrer cada fila de resultados
    while ($row = $result->fetch_assoc()) {
        // Agregar cada fila al array de respuesta
        $response[] = $row;
    }

    // Codificar el array de respuesta como JSON y enviarlo
    echo json_encode($response);
} else {
    // No se encontraron resultados
    echo "No se encontraron datos.";
}

// Cerrar conexión
$conn->close();

?>
