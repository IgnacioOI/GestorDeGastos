<?php

$servername = "localhost";
$username = "id21849132_adminlistacompra1";
$password = "ListaCompra_1";
$dbname = "id21849132_listacompra";



$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $nombre = $_POST["nombre"];
    $tipo = $_POST["tipo"];
    $idListaCompra = $_POST["id_lista_compra"];

    $sql = "INSERT INTO Productos (nombre, tipo, idListaCompra) VALUES (?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssi", $nombre, $tipo, $idListaCompra);

    if ($stmt->execute()) {
        echo "Producto insertado correctamente.";
    } else {
        echo "Error al insertar producto: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario para Insertar Producto</title>
</head>
<body>

<h2>Insertar Producto</h2>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required><br><br>
    <label for="tipo">Tipo:</label>
    <select name="tipo">
        <option value="fresco">Fresco</option>
        <option value="enlatado">Enlatado</option>
        <option value="embutido">Embutido</option>
    </select><br><br>
    <label for="id_lista_compra">ID Lista de Compra:</label>
    <input type="number" name="id_lista_compra" required><br><br>
    <input type="submit" value="Insertar Producto">
</form>

</body>
</html>
