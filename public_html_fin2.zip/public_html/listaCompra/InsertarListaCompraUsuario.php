<?php

$host = "localhost";
$usuario = "id21849132_adminlistacompra1";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_listacompra";


$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);

if (!$conexion) {
    die("Error al conectar a la base de datos: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['idUsuario']) && isset($_POST['titulo'])) {
    
        $idUsuario = $_POST['idUsuario'];
        $titulo = $_POST['titulo'];

        
        $sql = "INSERT INTO ListasCompra (titulo, idUsuario) VALUES ('$titulo', $idUsuario)";

       
        if (mysqli_query($conexion, $sql)) {
            echo "Nueva lista de compras creada exitosamente";
        } else {
            echo "Error al crear la lista de compras: " . mysqli_error($conexion);
        }
    } else {
        echo "Por favor, asegúrate de enviar los datos 'idUsuario' y 'titulo' en la solicitud POST.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Nueva Lista de Compras</title>
</head>
<body>
    <h2>Crear Nueva Lista de Compras</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <label for="idUsuario">ID Usuario:</label>
        <input type="text" id="idUsuario" name="idUsuario" required><br><br>
        
        <label for="titulo">Título Lista:</label>
        <input type="text" id="titulo" name="titulo" required><br><br>
        
        <input type="submit" value="Crear Lista">
    </form>
</body>
</html>
