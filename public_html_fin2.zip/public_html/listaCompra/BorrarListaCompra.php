
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["idLista"])) {
        $idLista = $_POST["idLista"];

        $servername = "localhost";
        $username = "id21849132_adminlistacompra1";
        $password = "ListaCompra_1";
        $dbname = "id21849132_listacompra";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Error de conexión: " . $conn->connect_error);
        }

        $sql = "DELETE ListasCompra, Productos, CompartirLista FROM ListasCompra LEFT JOIN Productos ON ListasCompra.id = Productos.idListaCompra LEFT JOIN CompartirLista ON ListasCompra.id = CompartirLista.idListaCompra WHERE ListasCompra.id = $idLista";

        if ($conn->query($sql) === TRUE) {
            echo "La lista y todos los datos relacionados se eliminaron correctamente.";
        } else {
            echo "Error al eliminar la lista y los datos relacionados: " . $conn->error;
        }

        $conn->close();
    } else {
        echo "El parámetro 'idLista' no se recibió.";
    }
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Lista de Compra</title>
</head>
<body>
    <h1>Eliminar Lista de Compra</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="idLista">ID de la Lista:</label>
        <input type="text" id="idLista" name="idLista" required><br><br>
        <button type="submit">Eliminar Lista</button>
    </form>
</body>
</html>
