<?php
// Datos de conexión a la base de datos (ajusta estos valores según tu configuración)
$servername = "localhost";
$username = "id21849132_adminlistacompra1";
$password = "ListaCompra_1";
$dbname = "id21849132_listacompra";

// Recibe el nombre de usuario a buscar desde un formulario o solicitud GET/POST
$nombre_usuario = $_POST['nombre_usuario']; // Cambia a $_GET si estás recibiendo los datos por GET

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para buscar al usuario por su nombre
$sql = "SELECT * FROM Usuarios WHERE nombre = ?";

// Preparar la consulta
$stmt = $conn->prepare($sql);

// Vincular parámetros
$stmt->bind_param("s", $nombre_usuario);

// Ejecutar consulta
$stmt->execute();

// Obtener resultado de la consulta
$result = $stmt->get_result();

// Verificar si se encontró algún usuario con ese nombre
if ($result->num_rows > 0) {
    // Mostrar los datos del usuario encontrado
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . "<br>";
        echo "Nombre: " . $row["nombre"] . "<br>";
        echo "Contraseña: " . $row["password"] . "<br>";
    }
} else {
    echo "No se encontró ningún usuario con ese nombre.";
}

// Cerrar conexión
$stmt->close();
$conn->close();
?>
