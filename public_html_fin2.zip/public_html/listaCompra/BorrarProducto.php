<?php
if (isset($_POST['id_producto'])) {
    $idProducto = $_POST['id_producto'];
$servername = "localhost";
$username = "id21849132_adminlistacompra1";
$password = "ListaCompra_1";
$dbname = "id21849132_listacompra";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "DELETE FROM Productos WHERE id = $idProducto";

    if ($conn->query($sql) === TRUE) {
        echo "Producto borrado exitosamente.";
    } else {
        echo "Error al borrar el producto: " . $conn->error;
    }

    $conn->close();
} else {
    echo "ID de producto no válido.";
}
?>
