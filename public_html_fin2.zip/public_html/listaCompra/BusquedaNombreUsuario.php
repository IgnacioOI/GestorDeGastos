<?php

$host = "localhost";
$usuario = "id21849132_adminlistacompra1";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_listacompra";

$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
echo json_encode(array("error" => "Error al conectar a la base de datos: " . mysqli_connect_error()));
exit();
}

$nombreUsuario = $_POST["nombre"];
$contraUsuario = $_POST["contra"];

$sql = "SELECT * FROM Usuarios WHERE nombre = '$nombreUsuario' AND contrasena = '$contraUsuario'";

$resultado = mysqli_query($conexion, $sql);
if (!$resultado) {
echo json_encode(array("error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)));
exit();
}

if (mysqli_num_rows($resultado) > 0) {$usuario = mysqli_fetch_assoc($resultado);
echo json_encode(array("usuario" => $usuario));
} else {
echo json_encode(array("error" => "No se encontró ningún usuario con el nombre " . $nombreUsuario));
}

mysqli_close($conexion);

?>
