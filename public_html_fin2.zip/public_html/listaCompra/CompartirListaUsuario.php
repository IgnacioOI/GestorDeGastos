<?php
$servername = "localhost";
$username = "id21849132_adminlistacompra1";
$password = "ListaCompra_1";
$dbname = "id21849132_listacompra";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idListaCompra = $_POST["id_lista_compra"];
    $idUsuarioCompartido = $_POST["id_usuario_compartido"];

    $sql = "INSERT INTO CompartirLista (idListaCompra, idUsuarioCompartido) VALUES (?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ii", $idListaCompra, $idUsuarioCompartido);

    if ($stmt->execute()) {
        echo "Lista compartida exitosamente.";
    } else {
        echo "Error al compartir la lista: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compartir Lista de Compra</title>
</head>
<body>
    <h2>Compartir Lista de Compra</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <label for="id_lista_compra">ID de la Lista de Compra:</label><br>
        <input type="text" id="id_lista_compra" name="id_lista_compra"><br><br>
        <label for="id_usuario_compartido">ID del Usuario a Compartir:</label><br>
        <input type="text" id="id_usuario_compartido" name="id_usuario_compartido"><br><br>
        <input type="submit" value="Compartir Lista">
    </form>
</body>
</html>
