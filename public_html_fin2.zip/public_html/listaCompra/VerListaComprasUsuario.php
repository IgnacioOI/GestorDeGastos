<?php

$host = "localhost";
$usuario = "id21849132_adminlistacompra1";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_listacompra";

$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(array("error" => "Error al conectar a la base de datos: " . mysqli_connect_error()));
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['idUsu'])) {
        $idUsuario = $_REQUEST['idUsu'];

       
        $sql = "SELECT * FROM ListasCompra WHERE idUsuario = '$idUsuario'";
        $resultado = mysqli_query($conexion, $sql);

        if (!$resultado) {
            echo json_encode(array("error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)));
        } else {
            // Verificar si se encontraron listas de compra
            if (mysqli_num_rows($resultado) > 0) {
                $listasCompra = array();
                while ($row = mysqli_fetch_assoc($resultado)) {
                    $listasCompra[] = $row;
                }
                echo json_encode($listasCompra);
            } else {
                echo json_encode(array("error" => "No se encontraron listas de compra para el usuario con ID " . $idUsuario));
            }
        }
    }
}
?>
