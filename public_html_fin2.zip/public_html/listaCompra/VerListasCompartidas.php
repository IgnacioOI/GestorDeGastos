<?php
$servername = "localhost";
$username = "id21849132_adminlistacompra1";
$password = "ListaCompra_1";
$dbname = "id21849132_listacompra";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$tuid = $_GET['tu_id'];

$sql = "SELECT LC.id, LC.titulo, LC.compartir, LC.idUsuario
        FROM ListasCompra LC
        INNER JOIN CompartirLista CL ON LC.id = CL.idListaCompra
        WHERE CL.idUsuarioCompartido = $tuid";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo "0 resultados";
}

// Cerrar conexión
$conn->close();
?>
