<?php
$host = "localhost";
$usuario = "id21849132_adminlistacompra1";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_listacompra";

$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(array("error" => "Error al conectar a la base de datos: " . mysqli_connect_error()));
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['idCompra'])) {
        $idCompra = $_GET['idCompra'];

        $sql = "SELECT * FROM Productos WHERE idListaCompra = $idCompra";
        $resultado = mysqli_query($conexion, $sql);

        if (!$resultado) {
            echo json_encode(array("error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)));
        } else {
            if (mysqli_num_rows($resultado) > 0) {
                $productos = array();
                while ($row = mysqli_fetch_assoc($resultado)) {
                    $productos[] = $row;
                }
                echo json_encode($productos);
            } else {
                echo json_encode(array("error" => "No se encontraron productos para la lista de compra con ID " . $idCompra));
            }
        }
    } else {
        echo json_encode(array("error" => "Por favor, proporciona un ID de lista de compra."));
    }
} else {
    echo json_encode(array("error" => "Método de solicitud no permitido."));
}
?>
