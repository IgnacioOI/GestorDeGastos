<?php

$host = "localhost";
$usuario = "id21849132_adminlistacompra1";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_listacompra";

$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(array("error" => "Error al conectar a la base de datos: " . mysqli_connect_error()));
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $idProducto = $_POST['idProducto'];
    $cumplido = $_POST['cumplido'];

    $sql = "UPDATE Productos SET cumplido = '$cumplido' WHERE id = '$idProducto'";

    // Ejecutar la consulta SQL
    if (mysqli_query($conexion, $sql)) {
        echo json_encode(array("message" => "Estado de cumplimiento del producto actualizado correctamente"));
    } else {
        echo json_encode(array("error" => "Error al actualizar el estado de cumplimiento del producto: " . mysqli_error($conexion)));
    }
} else {
    echo json_encode(array("error" => "Método de solicitud incorrecto, se esperaba POST"));
}

mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Estado de Cumplimiento del Producto</title>
</head>
<body>
    <h1>Actualizar Estado de Cumplimiento del Producto</h1>
    <form action="" method="post">
        <label for="idProducto">ID del Producto:</label>
        <input type="text" id="idProducto" name="idProducto" required><br><br>
        
        <label for="cumplido">Nuevo Estado de Cumplimiento:</label>
        <select id="cumplido" name="cumplido" required>
            <option value="0">No cumplido</option>
            <option value="1">Cumplido</option>
        </select><br><br>
        
        <button type="submit">Actualizar Estado</button>
    </form>
</body>
</html>
