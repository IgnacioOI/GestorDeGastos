<?php
$servername = "localhost";
$username = "id21849132_elgranadmin";
$password = "ElGranAdmin000.";
$dbname = "id21849132_lagranbd";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Si se ha enviado el formulario, procesar y agregar los datos a la base de datos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Preparar la consulta SQL con marcadores de posición (?)
    $sql = "INSERT INTO persona (email, nombre, telefono, dni) VALUES (?, ?, ?, ?)";
    
    // Preparar la sentencia SQL
    $stmt = $conn->prepare($sql);

    // Vincular parámetros
    $stmt->bind_param("ssss", $email, $nombre, $telefono, $dni);

    // Asignar valores a los parámetros
    $email = $_POST["email"];
    $nombre = $_POST["nombre"];
    $telefono = $_POST["telefono"];
    $dni = $_POST["dni"];

    // Ejecutar la sentencia preparada
    if ($stmt->execute()) {
        echo "Datos agregados correctamente.";
    } else {
        echo "Error al agregar datos: " . $conn->error;
    }

    // Cerrar la sentencia
    $stmt->close();
}

// Mostrar datos existentes
$sql_select = "SELECT * FROM persona";
$result = $conn->query($sql_select);

$datos = array(); // Array para almacenar los datos

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $datos[] = $row; // Almacena cada fila de datos en el array
    }
} else {
    echo "No hay datos en la base de datos.";
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario y Base de Datos</title>
</head>
<body>

<h1>Formulario</h1>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="email">Email:</label>
    <input type="text" name="email" required>
    <br>
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required>
    <br>
    <label for="telefono">Teléfono:</label>
    <input type="text" name="telefono" required>
    <br>
    <label for="dni">DNI:</label>
    <input type="text" name="dni" required>
    <br>
    <input type="submit" value="Enviar">
</form>

<?php if (!empty($datos)): ?>
    <h2>Datos existentes en la base de datos:</h2>
    <table border='1'>
        <tr>
            <th>Email</th>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>DNI</th>
        </tr>
        <?php foreach ($datos as $dato): ?>
            <tr>
                <td><?php echo $dato['email']; ?></td>
                <td><?php echo $dato['nombre']; ?></td>
                <td><?php echo $dato['telefono']; ?></td>
                <td><?php echo $dato['dni']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

</body>
</html>
