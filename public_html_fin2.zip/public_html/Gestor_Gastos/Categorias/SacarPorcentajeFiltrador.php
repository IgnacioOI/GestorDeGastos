<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$database = "id21849132_gestorgatos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Comprobar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Tipo de gasto y cuenta deseada (puedes ajustar estos valores según tus necesidades)
$tipo_movimiento = $_POST["tipo_movimiento"]; // Suponiendo que recibes este valor desde la solicitud
$id_cuenta = $_POST["id_cuenta"]; // Suponiendo que recibes este valor desde la solicitud
$fecha_inicio = isset($_POST["fecha_inicio"]) ? $_POST["fecha_inicio"] : null;
$fecha_fin = isset($_POST["fecha_fin"]) ? $_POST["fecha_fin"] : null;

// Construir la consulta SQL con condiciones opcionales para las fechas
$sql = "SELECT c.id_categoria, c.nombre, c.color, SUM(m.cantidad) AS total_gastado 
        FROM Movimientos m
        INNER JOIN Categorias c ON c.id_categoria = m.id_categoria
        WHERE m.tipo_movimiento = '$tipo_movimiento' AND m.id_cuenta = $id_cuenta";

if (!empty($fecha_inicio) && !empty($fecha_fin)) {
    $sql .= " AND m.fecha BETWEEN '$fecha_inicio' AND '$fecha_fin'";
} elseif (!empty($fecha_inicio)) {
    $sql .= " AND m.fecha = '$fecha_inicio'";
}

// Agrupar por categoría
$sql .= " GROUP BY c.id_categoria";

// Ejecutar la consulta
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Array para almacenar los resultados
    $resultados = array();

    // Calcular el total gastado en todas las categorías
    $total_general = 0;
    while ($row = $result->fetch_assoc()) {
        $total_general += $row["total_gastado"];
    }

    // Volver a ejecutar la consulta para obtener los resultados
    $result->data_seek(0);
    while ($row = $result->fetch_assoc()) {
        $id_categoria = $row["id_categoria"];
        $total_gastado = $row["total_gastado"];
        // Calcular el porcentaje de gasto para esta categoría
        $porcentaje_gasto = ($total_gastado / $total_general) * 100;
        // Almacenar el resultado en un array asociativo
        $resultado = array("id_categoria" => $id_categoria, "nombre" => $row["nombre"], "color" => $row["color"], "porcentaje_gasto" => $porcentaje_gasto);
        // Agregar el resultado al array de resultados
        array_push($resultados, $resultado);
    }

    // Devolver los resultados como JSON
    echo json_encode($resultados);
} else {
    echo "0 resultados";
}

// Cerrar la conexión
$conn->close();
?>
