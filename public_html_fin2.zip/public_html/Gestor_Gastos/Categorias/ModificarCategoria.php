<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Categoría</title>
</head>
<body>
    <h2>Actualizar Categoría</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="id_categoria">ID Categoría:</label>
        <input type="text" id="id_categoria" name="id_categoria" required><br><br>
        
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>
        
        <label for="color">Color:</label>
        <input type="text" id="color" name="color" required><br><br>
        
        <label for="icono">Icono:</label>
        <input type="file" id="icono" name="icono"><br><br>
        
        <label for="tipo_movimiento">Tipo de Movimiento:</label>
        <select id="tipo_movimiento" name="tipo_movimiento" required>
            <option value="gasto">Gasto</option>
            <option value="ingreso">Ingreso</option>
        </select><br><br>
        
        <input type="submit" name="submit" value="Actualizar Categoría">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "id21849132_gestorgatosadmin";
        $password = "ListaCompra_1";
        $dbname = "id21849132_gestorgatos";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("La conexión falló: " . $conn->connect_error);
        }

        // Datos a actualizar
        $id_categoria = $_POST['id_categoria'];
        $nombre = $_POST['nombre'];
        $color = $_POST['color'];
        $tipo_movimiento = $_POST['tipo_movimiento'];

        // Manejo del icono
        $icono = null;
        $actualizar_icono = false;
        if (!empty($_FILES['icono']['tmp_name'])) {
            $icono = file_get_contents($_FILES['icono']['tmp_name']);
            $actualizar_icono = true;
        }

        // Preparar y ejecutar la consulta de actualización
        if ($actualizar_icono) {
            $sql = "UPDATE Categorias SET nombre=?, color=?, icono=?, tipo_movimiento=? WHERE id_categoria=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssbsi", $nombre, $color, $icono, $tipo_movimiento, $id_categoria);
            $stmt->send_long_data(2, $icono); // Enviar datos largos para el campo BLOB
        } else {
            $sql = "UPDATE Categorias SET nombre=?, color=?, tipo_movimiento=? WHERE id_categoria=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $nombre, $color, $tipo_movimiento, $id_categoria);
        }

        if ($stmt->execute()) {
            echo "Categoría actualizada exitosamente.";
        } else {
            echo "Error actualizando la categoría: " . $conn->error;
        }

        // Cerrar conexión
        $stmt->close();
        $conn->close();
    }
    ?>
</body>
</html>
