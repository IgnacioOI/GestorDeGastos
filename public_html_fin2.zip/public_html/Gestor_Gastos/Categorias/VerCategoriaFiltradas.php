<?php
// Permitir solicitudes desde cualquier origen
header("Access-Control-Allow-Origin: *");

// Verificar si se proporcionó el parámetro tipo_movimiento en la solicitud
if(isset($_GET['tipo_movimiento'])) {
    $tipo_movimiento = $_GET['tipo_movimiento'];
} else {
    // Si no se proporciona el parámetro, establecer un valor predeterminado (por ejemplo, 'Gasto')
    $tipo_movimiento = 'Gasto';
}

// Conexión a la base de datos (ajusta los valores según tu configuración)
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$database = "id21849132_gestorgatos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta SQL para obtener todas las categorías filtradas por tipo_movimiento
$sql = "SELECT id_categoria, nombre, tipo_movimiento, color, icono FROM Categorias WHERE tipo_movimiento = '$tipo_movimiento'";
$result = $conn->query($sql);

// Crear un array para almacenar las categorías
$categorias = array();

// Verificar si se obtuvieron resultados de la consulta
if ($result->num_rows > 0) {
    // Obtener cada fila de resultados y agregarla al array de categorías
    while($row = $result->fetch_assoc()) {
        // Verificar si hay una imagen asociada a la categoría
        if (!empty($row['icono'])) {
            // Obtener el contenido binario de la imagen
            $imagenBinaria = $row['icono'];
            // Convertir la imagen binaria a una cadena Base64
            $imagenBase64 = base64_encode($imagenBinaria);
            // Agregar la imagen codificada en Base64 al array de la categoría
            $row['icono'] = $imagenBase64;
        }
        $categorias[] = $row;
    }
}

// Cerrar la conexión
$conn->close();

// Configurar el tipo de contenido en la respuesta
header('Content-Type: application/json');

// Devolver los resultados en formato JSON
echo json_encode($categorias);
?>
