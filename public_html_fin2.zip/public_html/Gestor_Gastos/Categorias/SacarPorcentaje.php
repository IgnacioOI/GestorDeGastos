<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$database = "id21849132_gestorgatos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Comprobar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Tipo de gasto y cuenta deseada (puedes ajustar estos valores según tus necesidades)
$tipo_movimiento = $_POST["tipo_movimiento"]; // Suponiendo que recibes este valor desde la solicitud
$id_cuenta = $_POST["id_cuenta"]; // Suponiendo que recibes este valor desde la solicitud

// Consulta SQL para obtener el total gastado en cada categoría, filtrando por tipo de movimiento y cuenta
$sql = "SELECT c.id_categoria, c.nombre, c.color, SUM(m.cantidad) AS total_gastado 
        FROM Movimientos m
        INNER JOIN Categorias c ON c.id_categoria = m.id_categoria
        WHERE m.tipo_movimiento = '$tipo_movimiento' AND m.id_cuenta = $id_cuenta
        GROUP BY c.id_categoria";

// Ejecutar la consulta
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Array para almacenar los resultados
    $resultados = array();

    // Calcular el total gastado en todas las categorías
    $total_general = 0;
    while ($row = $result->fetch_assoc()) {
        $total_general += $row["total_gastado"];
    }

    // Volver a ejecutar la consulta para obtener los resultados
    $result->data_seek(0);
    while ($row = $result->fetch_assoc()) {
        $id_categoria = $row["id_categoria"];
        $total_gastado = $row["total_gastado"];
        // Calcular el porcentaje de gasto para esta categoría
        $porcentaje_gasto = ($total_gastado / $total_general) * 100;
        // Almacenar el resultado en un array asociativo
        $resultado = array("id_categoria" => $id_categoria, "nombre" => $row["nombre"], "color" => $row["color"], "porcentaje_gasto" => $porcentaje_gasto);
        // Agregar el resultado al array de resultados
        array_push($resultados, $resultado);
    }

    // Devolver los resultados como JSON
    echo json_encode($resultados);
} else {
    echo "0 resultados";
}

// Cerrar la conexión
$conn->close();
?>
