<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$database = "id21849132_gestorgatos";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$sql = "SELECT * FROM Categorias";

$result = $conn->query($sql);

$categorias = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $categorias[] = $row;
    }
}

// Cerrar la conexión
$conn->close();

$json_categorias = json_encode($categorias);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Categorías</title>
</head>
<body>
    <h1>Consulta de Categorías</h1>
    <div id="categorias"></div>

    <!-- Incluir jQuery para facilitar el manejo de JSON -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Función para cargar los datos de las categorías
        function cargarCategorias() {
            $.ajax({
                url: 'VerCategorias.php',
                dataType: 'json',
                success: function(data) {
                    mostrarCategorias(data);
                }
            });
        }

        // Función para mostrar las categorías en la página
        function mostrarCategorias(categorias) {
            var html = '<ul>';
            categorias.forEach(function(categoria) {
                html += '<li>ID: ' + categoria.id + ', Nombre: ' + categoria.nombre + ', Descripción: ' + categoria.descripcion + '</li>';
            });
            html += '</ul>';
            $('#categorias').html(html);
        }

        // Cargar las categorías cuando la página esté lista
        $(document).ready(function() {
            cargarCategorias();
        });
    </script>
</body>
</html>

<?php
// Imprimir el JSON de categorías
echo $json_categorias;
?>
