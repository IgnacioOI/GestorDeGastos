<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar Usuario</title>
</head>
<body>
    <h2>Insertar Usuario</h2>
    <form action=" InsertarUsuario.php" method="post">
        <label for="nombre">Nombre de Usuario:</label><br>
        <input type="text" id="nombre" name="nombre"><br>
        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña"><br><br>
        <input type="submit" value="Insertar Usuario">
    </form>

    <?php
    // Script PHP para procesar el formulario
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $username = "id21849132_gestorgatosadmin";
        $password = "ListaCompra_1";
        $dbname = "id21849132_gestorgatos";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Error en la conexión: " . $conn->connect_error);
        }

        // Recuperar datos del formulario
        $nombre = $_POST["nombre"];
        $contraseña = $_POST["contraseña"];

        // Consulta SQL para insertar un usuario
        $sql = "INSERT INTO Usuarios (nombre, contrasena) VALUES ('$nombre', '$contraseña')";

        // Ejecutar la consulta
        if ($conn->query($sql) === TRUE) {
            echo "Usuario insertado correctamente.";
        } else {
            echo "Error al insertar el usuario: " . $conn->error;
        }

        // Cerrar la conexión
        $conn->close();
    }
    ?>
</body>
</html>
