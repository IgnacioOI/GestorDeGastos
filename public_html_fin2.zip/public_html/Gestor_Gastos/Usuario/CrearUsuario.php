<?php
$host = "localhost";
$usuario = "id21849132_gestorgatosadmin";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_gestorgatos";
$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(["error" => "Error al conectar a la base de datos: " . mysqli_connect_error()]);
    exit; // Termina la ejecución del script después de enviar la respuesta JSON
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['nombre']) && isset($_POST['contrasena'])) {
        $nombreUsuario = $_POST['nombre'];
        $contrasenaUsuario = $_POST['contrasena'];

        // Verificar si el usuario ya existe en la base de datos
        $sql = "SELECT * FROM Usuarios WHERE nombre = '$nombreUsuario'";
        $resultado = mysqli_query($conexion, $sql);

        if (!$resultado) {
            echo json_encode(["error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)]);
            exit; // Termina la ejecución del script después de enviar la respuesta JSON
        }

        if (mysqli_num_rows($resultado) > 0) {
            echo json_encode(["error" => "El usuario ya existe."]);
            exit; // Termina la ejecución del script después de enviar la respuesta JSON
        } else {
            // Insertar el nuevo usuario en la base de datos
            $sqlInsert = "INSERT INTO Usuarios (nombre, contrasena) VALUES ('$nombreUsuario', '$contrasenaUsuario')";
            if (mysqli_query($conexion, $sqlInsert)) {
                echo json_encode(["message" => "Usuario creado exitosamente."]);
                exit; // Termina la ejecución del script después de enviar la respuesta JSON
            } else {
                echo json_encode(["error" => "Error al crear el usuario: " . mysqli_error($conexion)]);
                exit; // Termina la ejecución del script después de enviar la respuesta JSON
            }
        }
    }
}

// Si la solicitud no es POST o si falta algún parámetro en la solicitud
echo json_encode(["error" => "Solicitud inválida"]);
exit; // Termina la ejecución del script después de enviar la respuesta JSON
?>
