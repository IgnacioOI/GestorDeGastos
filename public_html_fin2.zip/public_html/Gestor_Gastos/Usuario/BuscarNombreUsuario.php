<?php
$host = "localhost";
$usuario = "id21849132_gestorgatosadmin";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_gestorgatos";

$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(array("error" => "Error al conectar a la base de datos: " . mysqli_connect_error()));
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['nombre'])) {
        $nombreUsuario = $_GET['nombre'];
       

        // Consulta SQL para buscar el usuario
        $sql = "SELECT nombre FROM Usuarios WHERE nombre = '$nombreUsuario'";
        $resultado = mysqli_query($conexion, $sql);

        if (!$resultado) {
            echo json_encode(array("error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)));
        } else {
            // Verificar si se encontró un usuario
            if (mysqli_num_rows($resultado) > 0) {
                $usuarios = array();
                while ($row = mysqli_fetch_assoc($resultado)) {
                    $usuarios[] = $row; 
                }
                echo json_encode($usuarios);
            } else {
                echo json_encode(array("error" => "No se encontró ningún usuario con el nombre " . $nombreUsuario));
            }
        }
    }
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>
