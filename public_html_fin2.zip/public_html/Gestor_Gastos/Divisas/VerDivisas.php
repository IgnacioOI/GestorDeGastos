<?php
// Permitir solicitudes desde cualquier origen
header("Access-Control-Allow-Origin: *");

// Conexión a la base de datos (ajusta los valores según tu configuración)
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$database = "id21849132_gestorgatos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta SQL para obtener todas las divisas
$sql = "SELECT nombre, simbolo,id FROM divisas";
$result = $conn->query($sql);

// Crear un array para almacenar las divisas
$divisas = array();

// Verificar si se obtuvieron resultados de la consulta
if ($result->num_rows > 0) {
    // Obtener cada fila de resultados y agregarla al array de divisas
    while($row = $result->fetch_assoc()) {
        $divisas[] = $row;
    }
}

// Cerrar la conexión
$conn->close();

// Devolver los resultados en formato JSON
header('Content-Type: application/json');
echo json_encode($divisas);
?>
