
    
    <!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categorías con Imágenes</title>
</head>
<body>
    <h2>Categorías con Imágenes</h2>

    <?php
    // Conexión a la base de datos
    $servername = "localhost";
    $username = "id21849132_gestorgatosadmin";
    $password = "ListaCompra_1";
    $dbname = "id21849132_gestorgatos";
    
    
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    // Consulta SQL para obtener todas las categorías
    $sql = "SELECT id_categoria, nombre, color, icono FROM Categorias";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Mostrar cada categoría con su imagen
        while($row = $result->fetch_assoc()) {
            echo "<div>";
            echo "<h3>" . $row["nombre"] . "</h3>";
            echo "<p>Color: " . $row["color"] . "</p>";
            // Mostrar la imagen
            echo '<img src="data:image/jpeg;base64,' . base64_encode($row["icono"]) . '" alt="Icono">';
            echo "</div>";
        }
    } else {
        echo "No se encontraron categorías.";
    }
    $conn->close();
    ?>
</body>
</html>
