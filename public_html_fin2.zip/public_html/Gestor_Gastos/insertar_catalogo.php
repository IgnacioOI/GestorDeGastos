<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar Categoría</title>
</head>
<body>
    <h2>Insertar Categoría</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <label for="nombre">Nombre de la Categoría:</label><br>
        <input type="text" id="nombre" name="nombre"><br>
        <label for="color">Color:</label><br>
        <input type="text" id="color" name="color"><br>
        <label for="icono">Icono:</label><br>
        <input type="file" id="icono" name="icono"><br><br>
        <input type="submit" value="Insertar Categoría">
    </form>
</body>
</html>
    <?php
    // Conexión a la base de datos
    $servername = "localhost";
    $username = "id21849132_gestorgatosadmin";
    $password = "ListaCompra_1";
    $dbname = "id21849132_gestorgatos";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    // Procesar el formulario si se ha enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $_POST["nombre"];
        $color = $_POST["color"];

        // Manejar el archivo de icono
        $icono = $_FILES["icono"]["tmp_name"];
        $iconoContenido = file_get_contents($icono);

        // Consulta SQL para insertar la categoría
        $sql = "INSERT INTO Categorias (nombre, color, icono) VALUES (?, ?, ?)";
        
        // Preparar la declaración SQL
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $nombre, $color, $iconoContenido);
        
        // Ejecutar la declaración
        if ($stmt->execute() === TRUE) {
            echo "Categoría insertada correctamente.";
        } else {
            echo "Error al insertar la categoría: " . $conn->error;
        }

        // Cerrar la conexión
        $stmt->close();
        $conn->close();
    }
    ?>

