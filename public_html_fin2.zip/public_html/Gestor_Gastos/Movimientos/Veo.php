<?php
// Verificar si se reciben datos POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conectar a la base de datos (cambiar los valores según tu configuración)
    $conn = new mysqli("localhost", "id21849132_gestorgatosadmin", "ListaCompra_1", "id21849132_gestorgatos");

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Obtener el ID de usuario, el ID de cuenta y el tipo de movimiento del POST
    $idUsuario = $_POST['id_usuario'];
    $idCuenta = $_POST['id_cuenta'];
    $tipoMovimiento = $_POST['tipo_movimiento'];

    // Consultar los movimientos del usuario, de la cuenta y del tipo de movimiento en la base de datos
    $sql = "SELECT m.*, c.icono, c.color,c.nombre FROM Movimientos m INNER JOIN Categorias c ON m.id_categoria = c.id_categoria WHERE m.id_usuario = ? AND m.id_cuenta = ? AND m.tipo_movimiento = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis", $idUsuario, $idCuenta, $tipoMovimiento);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $movimientos = array();

            while ($row = $result->fetch_assoc()) {
                // Verificar si hay una imagen asociada a la categoría
                if (!empty($row['icono'])) {
                    // Obtener el contenido binario de la imagen
                    $imagenBinaria = $row['icono'];
                    // Convertir la imagen binaria a una cadena Base64
                    $imagenBase64 = base64_encode($imagenBinaria);
                    // Agregar la imagen codificada en Base64 al array de la categoría
                    $row['icono'] = $imagenBase64;
                }
                $movimientos[] = $row;
            }

            // Convertir la lista de movimientos a formato JSON y devolverla
            echo json_encode($movimientos);
        } else {
            echo json_encode(array('message' => 'No hay movimientos para este usuario, esta cuenta y este tipo de movimiento.'));
        }
    } else {
        echo json_encode(array('message' => 'Error al consultar los movimientos.'));
    }

    // Cerrar la conexión
    $conn->close();
} else {
    echo json_encode(array('message' => 'Método no permitido.'));
}
?>
