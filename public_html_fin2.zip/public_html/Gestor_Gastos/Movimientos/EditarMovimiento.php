<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$dbname = "id21849132_gestorgatos"; 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die(json_encode(array("status" => "error", "message" => "Conexión fallida: " . $conn->connect_error)));
}

// Variables para el movimiento a modificar
$id_movimiento = $_POST['id_movimiento']; // Suponiendo que recibes esto desde un formulario
$nuevo_tipo_movimiento = $_POST['nuevo_tipo_movimiento']; // Suponiendo que recibes esto desde un formulario
$nuevo_id_categoria = $_POST['nuevo_id_categoria']; // Suponiendo que recibes esto desde un formulario
$nueva_cantidad = $_POST['nueva_cantidad']; // Suponiendo que recibes esto desde un formulario
$nueva_fecha = $_POST['nueva_fecha']; // Suponiendo que recibes esto desde un formulario

// Convertir el formato de la fecha (de DD/MM/AAAA a AAAA-MM-DD) para que sea compatible con MySQL
$nueva_fecha = date('Y-m-d', strtotime(str_replace('/', '-', $nueva_fecha)));

$nueva_descripcion = $_POST['nueva_descripcion']; // Suponiendo que recibes esto desde un formulario

// Query para actualizar el movimiento
$sql = "UPDATE Movimientos SET 
            tipo_movimiento = '$nuevo_tipo_movimiento',
            id_categoria = '$nuevo_id_categoria',
            cantidad = '$nueva_cantidad',
            fecha = '$nueva_fecha',
            descripcion = '$nueva_descripcion'
        WHERE id_movimiento = '$id_movimiento'";

if ($conn->query($sql) === TRUE) {
    $response = array(
        "status" => "success",
        "message" => "Movimiento actualizado correctamente",
        "data" => array(
            "id_movimiento" => $id_movimiento,
            "tipo_movimiento" => $nuevo_tipo_movimiento,
            "id_categoria" => $nuevo_id_categoria,
            "cantidad" => $nueva_cantidad,
            "fecha" => $nueva_fecha,
            "descripcion" => $nueva_descripcion
        )
    );
} else {
    $response = array(
        "status" => "error",
        "message" => "Error al actualizar el movimiento: " . $conn->error
    );
}

// Devolver respuesta en formato JSON
echo json_encode($response);

// Cerrar conexión
$conn->close();
?>
