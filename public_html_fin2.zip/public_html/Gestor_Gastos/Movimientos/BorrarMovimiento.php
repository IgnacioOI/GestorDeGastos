<?php
header('Content-Type: application/json'); // Asegurar que la respuesta sea JSON

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli("localhost", "id21849132_gestorgatosadmin", "ListaCompra_1", "id21849132_gestorgatos");

    if ($conn->connect_error) {
        echo json_encode(array('message' => 'Error de conexión: ' . $conn->connect_error));
        exit();
    }

    // Obtener el id_movimiento del POST y verificar que no esté vacío
    $idMovimiento = isset($_POST['id_movimiento']) ? $_POST['id_movimiento'] : null;

    if (!$idMovimiento) {
        echo json_encode(array('message' => 'Parámetro id_movimiento no proporcionado.'));
        $conn->close();
        exit();
    }

    // Preparar la declaración SQL para borrar el movimiento
    $sql = "DELETE FROM Movimientos WHERE id_movimiento = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $idMovimiento);
        
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo json_encode(array('message' => 'Movimiento borrado exitosamente.'));
            } else {
                echo json_encode(array('message' => 'No se encontró un movimiento con el id proporcionado.'));
            }
        } else {
            echo json_encode(array('message' => 'Error al borrar el movimiento. Detalles: ' . $stmt->error));
        }

        $stmt->close();
    } else {
        echo json_encode(array('message' => 'Error al preparar la declaración SQL.'));
    }

    $conn->close();
} else {
    echo json_encode(array('message' => 'Método no permitido.'));
}
?>
