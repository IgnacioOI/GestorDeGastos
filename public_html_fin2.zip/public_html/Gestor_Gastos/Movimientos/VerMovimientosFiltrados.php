<?php
header('Content-Type: application/json'); // Asegurar que la respuesta sea JSON

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli("localhost", "id21849132_gestorgatosadmin", "ListaCompra_1", "id21849132_gestorgatos");

    if ($conn->connect_error) {
        echo json_encode(array('message' => 'Error de conexión: ' . $conn->connect_error));
        exit();
    }

    // Obtener parámetros y verificar que no estén vacíos
    $idUsuario = isset($_POST['id_usuario']) ? $_POST['id_usuario'] : null;
    $idCuenta = isset($_POST['id_cuenta']) ? $_POST['id_cuenta'] : null;
    $tipoMovimiento = isset($_POST['tipo_movimiento']) ? $_POST['tipo_movimiento'] : null;
    
    $fechaInicio = !empty($_POST['fecha_inicio']) ? date('Y-m-d', strtotime($_POST['fecha_inicio'])) : null;
    $fechaFin = !empty($_POST['fecha_fin']) ? date('Y-m-d', strtotime($_POST['fecha_fin'])) : null;

    if (!$idUsuario || !$idCuenta || !$tipoMovimiento) {
        echo json_encode(array('message' => 'Parámetros requeridos no proporcionados.'));
        $conn->close();
        exit();
    }

    // Preparar la consulta SQL con uniones para obtener la divisa
    $sql = "SELECT m.*, d.simbolo AS divisa, c.icono AS icono, c.color,c.nombre
            FROM Movimientos m 
            INNER JOIN Cuentas cu ON m.id_cuenta = cu.id_cuenta 
            INNER JOIN divisas d ON cu.divisa_id = d.id 
            INNER JOIN Categorias c ON m.id_categoria = c.id_categoria
            WHERE m.id_usuario = ? AND m.id_cuenta = ? AND m.tipo_movimiento = ?";
    
    if ($fechaInicio && $fechaFin) {
        $sql .= " AND m.fecha BETWEEN ? AND ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iisss", $idUsuario, $idCuenta, $tipoMovimiento, $fechaInicio, $fechaFin);
    } elseif ($fechaInicio) {
        $sql .= " AND m.fecha >= ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $idUsuario, $idCuenta, $tipoMovimiento, $fechaInicio);
    } elseif ($fechaFin) {
        $sql .= " AND m.fecha <= ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $idUsuario, $idCuenta, $tipoMovimiento, $fechaFin);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $idUsuario, $idCuenta, $tipoMovimiento);
    }

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $movimientos = array();
            while ($row = $result->fetch_assoc()) {
                // Verificar si el campo 'icono' no está vacío
                if (!empty($row['icono'])) {
                    // Obtener el contenido binario de la imagen
                    $imagenBinaria = $row['icono'];
                    // Convertir la imagen binaria a una cadena Base64
                    $imagenBase64 = base64_encode($imagenBinaria);
                    // Agregar la imagen codificada en Base64 al array de la categoría
                    $row['icono'] = $imagenBase64;
                }
                // Agregar la fila al array de movimientos
                $movimientos[] = $row;
            }
            echo json_encode($movimientos);
        } else {
            echo json_encode(array('message' => 'No hay movimientos para este usuario, esta cuenta y este tipo de movimiento.'));
        }
    } else {
        echo json_encode(array('message' => 'Error al consultar los movimientos. Detalles: ' . $stmt->error));
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(array('message' => 'Método no permitido.'));
}
?>
