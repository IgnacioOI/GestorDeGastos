<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$dbname = "id21849132_gestorgatos"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$tipo_movimiento = $_POST['tipo_movimiento'];
$id_cuenta = $_POST['id_cuenta'];
$id_usuario = $_POST['id_usuario'];
$id_categoria = $_POST['id_categoria'];
$cantidad = $_POST['cantidad'];

// Convertir el formato de la fecha (de DD/MM/AAAA a AAAA-MM-DD) para que sea compatible con MySQL
$fecha = date('Y-m-d', strtotime(str_replace('/', '-', $_POST['fecha'])));

$descripcion = $_POST['descripcion'];

// Insertar el movimiento en la base de datos
$sql = "INSERT INTO Movimientos (tipo_movimiento, id_cuenta, id_usuario, id_categoria, cantidad, fecha, descripcion)
        VALUES ('$tipo_movimiento', '$id_cuenta', '$id_usuario', '$id_categoria', '$cantidad', '$fecha', '$descripcion')";

$response = array(); // Array para almacenar la respuesta JSON

if ($conn->query($sql) === TRUE) {
    $response['success'] = true;
    $response['message'] = "Movimiento agregado exitosamente.";
} else {
    $response['success'] = false;
    $response['message'] = "Error al agregar el movimiento: " . $conn->error;
}

// Cerrar la conexión
$conn->close();

// Devolver la respuesta como JSON
echo json_encode($response);
?>
