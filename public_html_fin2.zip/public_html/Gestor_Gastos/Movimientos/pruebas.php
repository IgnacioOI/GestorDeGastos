<?php
// Verificamos si se ha realizado una petición POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Nos conectamos a la base de datos
    $conexion = mysqli_connect("localhost", "id21849132_gestorgatosadmin", "ListaCompra_1", "id21849132_gestorgatos");

    // Verificamos si hay errores de conexión
    if (mysqli_connect_errno()) {
        // Si hay errores, devolvemos un mensaje de error en formato JSON
        echo json_encode(array("error" => "Error al conectar a MySQL: " . mysqli_connect_error()));
        exit(); // Terminamos el script
    }

    // Obtenemos el ID de usuario, ID de cuenta y tipo de movimiento enviados en la petición POST
    $idUsuario = $_POST['id_usuario']; 
    $idCuenta = $_POST['id_cuenta'];
    $tipoMovimiento = $_POST['tipo_movimiento'];

    // Construimos la consulta SQL para obtener los movimientos del usuario, de la cuenta y del tipo de movimiento
    $sql = "SELECT m.*,c.color 
            FROM Movimientos m 
            INNER JOIN Categorias c ON m.id_categoria = c.id_categoria 
            WHERE m.id_usuario = $idUsuario AND m.id_cuenta = $idCuenta AND m.tipo_movimiento = '$tipoMovimiento'";

    // Ejecutamos la consulta
    $resultado = mysqli_query($conexion, $sql);

    // Si hay movimientos, creamos un arreglo para almacenar los datos
    $datos = array();

    // Iteramos sobre los resultados y los almacenamos en el arreglo
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $datos[] = $fila;
    }

    // Devolvemos los datos en formato JSON
    echo json_encode($datos);

    // Cerramos la conexión a la base de datos
    mysqli_close($conexion);
}
?>
