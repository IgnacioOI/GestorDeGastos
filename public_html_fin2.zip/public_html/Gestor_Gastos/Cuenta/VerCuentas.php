<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cuentas de Usuario</title>
</head>
<body>
    <h2>Cuentas de Usuario</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
        <label for="idUsuario">ID de Usuario:</label><br>
        <input type="text" id="idUsuario" name="idUsuario"><br><br>
        <input type="submit" value="Mostrar Cuentas">
    </form>
</body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $conexion = mysqli_connect("localhost", "id21849132_gestorgatosadmin", "ListaCompra_1", "id21849132_gestorgatos");

    if (mysqli_connect_errno()) {
        echo json_encode(array("error" => "Error al conectar a MySQL: " . mysqli_connect_error()));
        exit();
    }

    $idUsuario = $_GET['idUsuario']; 

    $sql = "SELECT c.id_cuenta, c.id_usuario, c.nombre, c.saldo, d.simbolo AS simbolo 
            FROM Cuentas c 
            INNER JOIN divisas d ON c.divisa_id = d.id 
            WHERE c.id_usuario = $idUsuario";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        $datos = array();

        while ($fila = mysqli_fetch_assoc($resultado)) {
            $datos[] = $fila;
        }

        echo "<pre>" . json_encode($datos, JSON_PRETTY_PRINT) . "</pre>";
    } else {
        echo json_encode(array("mensaje" => "No se encontraron cuentas para el usuario con ID: $idUsuario."));
    }

    mysqli_close($conexion);
}
?>
