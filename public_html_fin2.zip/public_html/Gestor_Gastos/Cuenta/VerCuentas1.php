<?php
// Verificamos si se ha realizado una petición GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Nos conectamos a la base de datos
    $conexion = mysqli_connect("localhost", "id21849132_gestorgatosadmin", "ListaCompra_1", "id21849132_gestorgatos");

    // Verificamos si hay errores de conexión
    if (mysqli_connect_errno()) {
        // Si hay errores, devolvemos un mensaje de error en formato JSON
        echo json_encode(array("error" => "Error al conectar a MySQL: " . mysqli_connect_error()));
        exit(); // Terminamos el script
    }

    // Obtenemos el ID de usuario enviado en la petición GET
    $idUsuario = $_GET['idUsuario']; 

    // Construimos la consulta SQL para obtener las cuentas del usuario
    $sql = "SELECT c.id_cuenta, c.id_usuario, c.nombre, c.saldo, d.simbolo AS simbolo 
            FROM Cuentas c 
            INNER JOIN divisas d ON c.divisa_id = d.id 
            WHERE c.id_usuario = $idUsuario";

    // Ejecutamos la consulta
    $resultado = mysqli_query($conexion, $sql);

    // Si hay cuentas, creamos un arreglo para almacenar los datos
    $datos = array();

    // Iteramos sobre los resultados y los almacenamos en el arreglo
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $datos[] = $fila;
    }

    // Devolvemos los datos en formato JSON
    echo json_encode($datos);

    // Cerramos la conexión a la base de datos
    mysqli_close($conexion);
}
?>
