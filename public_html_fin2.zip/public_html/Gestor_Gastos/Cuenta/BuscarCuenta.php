<?php
$host = "localhost";
$usuario = "id21849132_gestorgatosadmin";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_gestorgatos";
$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(["error" => "Error al conectar a la base de datos: " . mysqli_connect_error()]);
    exit; // Termina la ejecución del script después de enviar la respuesta JSON
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Verificar si se recibieron los parámetros idCuenta y idUsuario
    if (isset($_GET['idCuenta'], $_GET['idUsuario'])) {
        $idCuenta = $_GET['idCuenta'];
        $idUsuario = $_GET['idUsuario'];

        // Consulta SQL para buscar la cuenta por idCuenta y idUsuario
        $sql = "SELECT * FROM Cuentas WHERE id_Cuenta = '$idCuenta' AND id_usuario = '$idUsuario'";
        $resultado = mysqli_query($conexion, $sql);

        if (!$resultado) {
            echo json_encode(["error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)]);
            exit; // Termina la ejecución del script después de enviar la respuesta JSON
        }

        // Verificar si se encontraron resultados
        if (mysqli_num_rows($resultado) > 0) {
            // Convertir el resultado a un array asociativo
            $cuenta = mysqli_fetch_assoc($resultado);
            echo json_encode($cuenta);
        } else {
            echo json_encode(["error" => "No se encontró la cuenta para el usuario especificado."]);
        }
    } else {
        echo json_encode(["error" => "Faltan parámetros en la solicitud."]);
    }
} else {
    echo json_encode(["error" => "Solicitud inválida"]);
}
mysqli_close($conexion);
?>
