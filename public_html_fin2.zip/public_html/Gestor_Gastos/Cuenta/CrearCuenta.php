<?php
$host = "localhost";
$usuario = "id21849132_gestorgatosadmin";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_gestorgatos";
$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);
if (!$conexion) {
    echo json_encode(["error" => "Error al conectar a la base de datos: " . mysqli_connect_error()]);
    exit; // Termina la ejecución del script después de enviar la respuesta JSON
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['idUsuario'], $_POST['nombreCuenta'], $_POST['saldoInicial'], $_POST['divisaId'])) {
        $idUsuario = $_POST['idUsuario'];
        $nombreCuenta = $_POST['nombreCuenta'];
        $saldoInicial = $_POST['saldoInicial'];
        $divisaId = $_POST['divisaId'];

        // Verificar si la cuenta ya existe en la base de datos
        $sql = "SELECT * FROM Cuentas WHERE nombre = '$nombreCuenta' AND id_usuario = '$idUsuario'";
        $resultado = mysqli_query($conexion, $sql);

        if (!$resultado) {
            echo json_encode(["error" => "Error al ejecutar la consulta: " . mysqli_error($conexion)]);
            exit; // Termina la ejecución del script después de enviar la respuesta JSON
        }

        if (mysqli_num_rows($resultado) > 0) {
            echo json_encode(["error" => "La cuenta ya existe para este usuario."]);
            exit; // Termina la ejecución del script después de enviar la respuesta JSON
        } else {
            // Insertar la nueva cuenta en la base de datos
            $sqlInsert = "INSERT INTO Cuentas (id_usuario, nombre, saldo, divisa_id) VALUES ('$idUsuario', '$nombreCuenta', '$saldoInicial', '$divisaId')";
            if (mysqli_query($conexion, $sqlInsert)) {
                echo json_encode(["message" => "Cuenta creada exitosamente."]);
                exit; // Termina la ejecución del script después de enviar la respuesta JSON
            } else {
                echo json_encode(["error" => "Error al crear la cuenta: " . mysqli_error($conexion)]);
                exit; // Termina la ejecución del script después de enviar la respuesta JSON
            }
        }
    }
}

// Si la solicitud no es POST o si falta algún parámetro en la solicitud
echo json_encode(["error" => "Solicitud inválida"]);
exit; // Termina la ejecución del script después de enviar la respuesta JSON
?>
