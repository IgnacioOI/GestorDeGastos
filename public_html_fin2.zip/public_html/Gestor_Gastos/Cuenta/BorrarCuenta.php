<?php

$host = "localhost";
$usuario = "id21849132_gestorgatosadmin";
$contrasena = "ListaCompra_1";
$baseDatos = "id21849132_gestorgatos";
$conexion = mysqli_connect($host, $usuario, $contrasena, $baseDatos);

if (!$conexion) {
    die("Error al conectar a la base de datos: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['idCuenta'], $_POST['idUsuario'])) {
    $idCuenta = $_POST['idCuenta'];
    $idUsuario = $_POST['idUsuario'];

    $sql = "DELETE FROM Cuentas WHERE id_Cuenta = '$idCuenta' AND id_usuario = '$idUsuario'";

    if (mysqli_query($conexion, $sql)) {
        echo json_encode(["success" => "Cuenta eliminada correctamente."]);
    } else {
        echo json_encode(["error" => "Error al eliminar la cuenta: " . mysqli_error($conexion)]);
    }
} else {
    echo json_encode(["error" => "Faltan parámetros en la solicitud."]);
}

mysqli_close($conexion);
?>
