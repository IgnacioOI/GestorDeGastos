<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$servername = "localhost";
$username = "id21849132_gestorgatosadmin";
$password = "ListaCompra_1";
$database = "id21849132_gestorgatos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexión
if ($conn->connect_error) {
    die(json_encode(array("error" => "Conexión fallida: " . $conn->connect_error)));
}

// Verificar si el ID del usuario se pasó como parámetro
if (!isset($_GET['id_usuario'])) {
    die(json_encode(array("error" => "ID de usuario no especificado")));
}

$id_usuario = intval($_GET['id_usuario']); // Asegurarse de que el ID del usuario es un entero

// Consulta para obtener el saldo total de cada cuenta del usuario
$sql = "SELECT cuentas.id_cuenta, cuentas.nombre,
               (COALESCE(movimientos.ingresos, 0) - COALESCE(movimientos.gastos, 0) + cuentas.saldo) AS saldo_total
        FROM Cuentas AS cuentas
        LEFT JOIN (
            SELECT id_cuenta,
                   SUM(CASE WHEN tipo_movimiento = 'Ingreso' THEN cantidad ELSE 0 END) AS ingresos,
                   SUM(CASE WHEN tipo_movimiento = 'Gasto' THEN cantidad ELSE 0 END) AS gastos
            FROM Movimientos
            GROUP BY id_cuenta
        ) AS movimientos ON cuentas.id_cuenta = movimientos.id_cuenta
        WHERE cuentas.id_usuario = $id_usuario";

$result = $conn->query($sql);

$response = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response[] = array(
            "id_cuenta" => $row["id_cuenta"],
            "nombre" => $row["nombre"],
            "saldo_total" => $row["saldo_total"]
        );
    }
} else {
    $response['error'] = "No se encontraron cuentas para el usuario especificado";
}

echo json_encode($response);

$conn->close();
?>
